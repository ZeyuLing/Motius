# SPDX-License-Identifier: GPL-3.0-or-later
DEFAULT_MODE = 'STANDARD'
